<?php
function my_autoloader($class) {
    // El prefijo del namespace (PhpOffice\PhpSpreadsheet)
    $prefix = 'PhpOffice\\PhpSpreadsheet\\';
    
    // El directorio donde están las clases de PhpSpreadsheet
    $base_dir = 'C:/xampp/htdocs/Brayan/libs/PhpSpreadsheet-master/src/PhpSpreadsheet/';

    // Si la clase no empieza con el prefijo esperado, la ignoramos
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    // Obtener el nombre relativo de la clase (sin el prefijo)
    $relative_class = substr($class, $len);

    // Convertir la clase a una ruta de archivo (reemplazar los nombres de los espacios de nombres por '/')
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    // Verificar si el archivo existe y cargarlo
    if (file_exists($file)) {
        require_once $file;
    }
}

// Registrar el autoloader
spl_autoload_register('my_autoloader');

?>
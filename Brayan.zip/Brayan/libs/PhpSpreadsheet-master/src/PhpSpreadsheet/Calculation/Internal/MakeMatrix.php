<?php

namespace PhpOffice\PhpSpreadsheet\Calculation\Internal;

class MakeMatrix
{
    /** @param array $args */
    public static function make(...$args): array
    {
        return $args;
    }
}
